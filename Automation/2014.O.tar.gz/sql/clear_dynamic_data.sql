delete from divisionals;
delete from events;
delete from individual_results;
delete from meets;
delete from relay_carnival;
delete from relay_results;
delete from swimmers;
delete from teams;
