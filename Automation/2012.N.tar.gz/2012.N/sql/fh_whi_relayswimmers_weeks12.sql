select a.event,
       f.text age,
       if(d.gender='M','Boys','Girls') gender,
       concat(d.distance,'M') distance,
       e.value stroke,
       a.team,
       a.relay_team,
       aa.name,
       bb.name,
       cc.name,
       dd.name,
       a.time,
       a.week
  from relay_results a,
       events d,
       sdif_codes e,
       age_codes f,
       swimmers aa,
       swimmers bb,
       swimmers cc,
       swimmers dd
  where a.team in ('PVFH','PVWHI')
    and d.number=a.event
    and f.code=d.age
    and e.block=12
    and e.code=d.stroke
    and aa.ussid=a.swimmer1
    and bb.ussid=a.swimmer2
    and cc.ussid=a.swimmer3
    and dd.ussid=a.swimmer4
    
 order by a.event,a.week,a.time