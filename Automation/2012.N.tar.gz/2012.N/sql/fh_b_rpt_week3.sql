select b.name,
       a.event,
       e.text,
       c.gender,
       concat(c.distance,'M') distance,
       d.value,
       a.place,
       a.dq 
from individual_results a, 
     swimmers b, 
     events c,
     sdif_codes d,
     age_codes e
where week=3
 and b.ussid=a.swimmer
 and c.number=a.event
 and b.team='PVFH'
 and d.block=12
 and d.code=c.stroke
 and e.code=c.age
order by b.name,event;