select a.event,
       f.text,
       if(d.gender='M','Boys','Girls'),
       concat(d.distance,'M'),
       e.value,
       a.team,
       a.relay_team,
       a.time week1,
       b.time week2
  from relay_results a,
       relay_results b,
       events d,
       sdif_codes e,
       age_codes f
  where a.event=b.event
    and a.team=b.team
    and a.relay_team=b.relay_team
    and a.week=1
    and b.week=2
    and a.team in ('PVFH','PVWHI')
    and d.number=a.event
    and f.code=d.age
    and e.block=12
    and e.code=d.stroke
 order by a.event,week2