select a.event,
       f.text age,
       if(d.gender='M','Boys','Girls') gender,
       concat(d.distance,'M') distance,
       e.value stroke,
       c.name,
       c.team,
       a.time,
       a.week
  from individual_results a,
       swimmers c,
       events d,
       sdif_codes e,
       age_codes f
 where c.ussid=a.swimmer
   and c.team in ('PVFH','PVWHI')
   and d.number=a.event
   and e.block=12
   and e.code=d.stroke
   and f.code=d.age
 order by a.event,a.time,a.week