delete from events;
delete from meets;
delete from teams;
delete from individual_results;
delete from relay_results;