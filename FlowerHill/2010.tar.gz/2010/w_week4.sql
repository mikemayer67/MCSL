select a.swimmer,
       a.place,
       b.name 
  from results a,
       events b 
 where a.year=2010 
   and a.week=4 
   and a.team='W' 
   and b.id=a.event 
 order by swimmer,
          name;
